/*
	Author: Chris(tian) "infiSTAR" Lorenzen
	Contact: infiSTAR23@gmail.com
	#baf1f9a48699
	
	cerberusexile.developer@gmail.com
	
	You should be able to download the latest update(s) on
	https://webinterface.infistar.de/download
*/
_______________________________________________________________________________________
The exile server config.cfg (the example file) has this
onHackedData                         = "ban (_this select 0)";

usually it was

onHackedData                         = "kick (_this select 0)";

It bans many players  on connect or during connecting  to your game-server, so change it back to kick.
_______________________________________________________________________________________
How to work with the custom billboards? How do I add pictures from my MPMission to them?
https://forum.infistar.de/index.php/Thread/6-HOWTO-infiSTAR-billboards/
_______________________________________________________________________________________
INSTALLATION:
English VIDEO GUIDE:
https://youtu.be/oNZMrs4G2ZE
	thanks TheFlyingJets!

01. Open the .zip file you have gotten from the store and go to "infiSTAR.de_Exile\ARMA3_SERVER_FOLDER\@infiSTAR_Exile\addons\a3_infiSTAR_Exile"
02. Open the "EXILE_AHAT_CONFIG.hpp" (do not edit the other files).
	- add your AdminUID(s)
	- check all the settings/options
	
	You need to set the serverCommandPassword to the serverCommandPassword you have in your servers Config.cfg
	if there is no serverCommandPassword in your Config.cfg yet, set it like:
	serverCommandPassword = "passwordhere";
	
	- It is the most important thing that you read carefully through the "EXILE_AHAT_CONFIG.hpp" and set all settings correctly for your server.

03. Now go to "infiSTAR.de_Exile\ARMA3_SERVER_FOLDER\@infiSTAR_Exile\addons"
	- make the folder you just changed the "EXILE_AHAT_CONFIG.hpp" in ("a3_infiSTAR_Exile") now to a pbo ("a3_infiSTAR_Exile.pbo") file.
		I always use PBO Manager (do a quick google search for it)
		as it allows me to simply right clickt the folder and "Pack into Pbo"

04. Move the whole "@infiSTAR_Exile" including the dll files and the addons\a3_infiSTAR_Exile.pbo to your ARMA3_SERVER_FOLDER

05. Go to "infiSTAR.de_Exile\MPMission"
	- move all the files into your currently used MPMission
	- Open the description.ext in your MPmission with a notepad
	
	- find "class CfgRemoteExec {};" (might also have something within the {} curly brackets)
	- remove it!
	- now add these 2 lines in the file:
	#include "CfgRemoteExec.hpp"
	#include "infiSTAR_AdminMenu.hpp"

06. Copy the BattleyeFilters from "infiSTAR.de_Exile\BattleEye" over into your Battleye folder on the Server.
	Be sure to copy them into the correct folder (FYI: that folder will also be where you will find *FILTERNAME*.log files of Battleye).
	If Battleye causes you trouble, scroll down this readme and read the guide(s) or use one of the tools.
	I am not affiliated with Battleye in any way and if the filters provided by me are not working with your modified server / mission - you have to deal with it yourself.
_______________________________________________________________________________________
Good to know - Keybinds:
1. You can spectate by double clicking the name of a player in the admin menu.
2. Keybinds:
	F1 - Default AdminMenu Key
	F2 - Territory Management (if you have the addon!)
	F2 & SHIFT - configviewer
	F3 - Adminconsole / Debug Console
	F4 - Treelist Item Spawn Menu
	F5 - Change Weather + View Distance
	F6 - Heal Yourself
	F7 - Heal & Repair withing 15m
	F8 - Flip CursorTarget Vehicle
	F9 - Show Gear of Player you are currently spectating (might close if player moves)
	F9 & SHIFT- To hide/show specate overlay (while spectating)
	F10 - Stop Spectating
	F11 - Add Ammo for current weapon
	1 & CTRL - Light / Zeus
	4 & SHIFT - Fly Up
	4 & CTRL - Teleport Up
	5 & SHIFT - Teleport in looking direction (if enabled)
	7 - Unlock/Lock targeted Vehicle
	7 - Opens/Closes targeted Door/Hatch/Gate
	B & SHIFT - Hover on position
	TAB & SHIFT - Open Map
	I & SHIFT - Show Info (Like Codes of Vehicles and Doors)
	DELETE - Delete CursorTarget

	Keybinds for EVERYONE (even normal players) - "Custom Controls"
	Custom Control 4 - Open infiSTAR Private Chat!

3. If the map is opened and you hold LEFT-ALT key, you can click on the map and teleport there!
4. If you are added in the "EXILE_AHAT_CONFIG.hpp" as an admin, you are able to change from admin to a normal player and back by typing !admin in the chat.
_______________________________________________________________________________________
BattlEye:
- on gtxgaming you need to put the supplied BE Filters into: Arma3Config/BattlEye (I know there are several folders named Battleye on the server but this is the only folder that matters!)

BattlEye Filters are time consuming and have to be changed depending on every small addon/script you do to your server/mission

These guides:
http://www.exilemod.com/topic/74-how-to-battleye-filters-do-it-yourself/?do=findComment&comment=1077
https://pastebin.com/9FBdjS1u

or these programs:
http://www.exilemod.com/topic/15394-battleye-automatic-script-exception-generator/
http://www.exilemod.com/topic/9708-battleye-filter-editor/

Personally for maximum security, I would add many different things like
7 "draw"
7 "public"
7 "create"
to my scripts.txt - then create the list of exceptions using one of the linked BE Filter programs

can help you solving the issue.
I am not affiliated with Battleye in any way and if the filters provided by me are not working with your modified server / mission - you have to deal with it yourself.
_______________________________________________________________________________________
armalog.dll
is creating the log files, doing the global ban check and more.
If you are running Linux, you can find all logs in your server rpt file too!

Linux users can also manually download the bans from:
htmlload.infistar.de/bans.php
htmlload.infistar.de/bebans.php
_______________________________________________________________________________________
You have problem?
send me the following:
	- server rpt file (complete file, not just a part of it - VERY IMPORTANT!)
	- client rpt file from you when you were trying to connect to the server, while it had the error
	- infiSTAR Log files (if it already wrote logs)
	- your current mpmission file
	- gameserver provider (if it is not your own dedi box - if it is your box, tell me)
	- server name
	- server mod(s) + version (of the mod(s))
	- custom scripts that could cause trouble
_______________________________________________________________________________________
/* *******************Developer : infiSTAR (infiSTAR23@gmail.com)******************* */
/* **************infiSTAR Copyright�� 2011 - 2016 All rights reserved.************** */
/* *********************************www.infiSTAR.de********************************* */